let userCount = 0;

function addUser() {
    userCount++;

    let div = document.createElement("div");
    div.innerHTML = `
        <h3>User ${userCount}</h3>
        <input placeholder="Name" id="name${userCount}">
        <select id="type${userCount}">
            <option value="veg">Veg</option>
            <option value="nonveg">Non-Veg</option>
        </select>
        <select id="cuisine${userCount}">
            <option value="indian">Indian</option>
            <option value="fast">Fast Food</option>
            <option value="chinese">Chinese</option>
        </select>
        <input type="number" placeholder="Budget" id="budget${userCount}">
        <input placeholder="Recently eaten" id="recent${userCount}">
        <hr>
    `;

    document.getElementById("users").appendChild(div);
}

function recommendFood() {

    let foods = [
        {name: "Pizza", type: "veg", cuisine: "fast", price: 200},
        {name: "Biryani", type: "nonveg", cuisine: "indian", price: 250},
        {name: "Dosa", type: "veg", cuisine: "indian", price: 100},
        {name: "Burger", type: "veg", cuisine: "fast", price: 150},
        {name: "Fried Rice", type: "veg", cuisine: "chinese", price: 180}
    ];

    let scores = {};
    foods.forEach(f => scores[f.name] = 0);

    for (let i = 1; i <= userCount; i++) {

        let type = document.getElementById(`type${i}`).value;
        let cuisine = document.getElementById(`cuisine${i}`).value;
        let budget = parseInt(document.getElementById(`budget${i}`).value);
        let recent = document.getElementById(`recent${i}`).value.toLowerCase();

        foods.forEach(food => {

            // ✅ Match veg/nonveg
            if (food.type === type) {
                scores[food.name] += 3;
            }

            // ✅ Match cuisine
            if (food.cuisine === cuisine) {
                scores[food.name] += 2;
            }

            // ✅ Budget check
            if (food.price <= budget) {
                scores[food.name] += 2;
            }

            // ❌ Avoid recent food
            if (food.name.toLowerCase() === recent) {
                scores[food.name] -= 5;
            }
        });
    }

    // Sort results
    let sorted = Object.entries(scores)
        .sort((a, b) => b[1] - a[1]);

    let resultText = "🍴 Best Choices:\n";

    sorted.slice(0, 3).forEach((item, index) => {
        resultText += `\n#${index+1} ${item[0]} (Score: ${item[1]})`;
    });

    document.getElementById("result").innerText = resultText;
}